from project.booths.booth import Booth
from project.delicacies.delicacy import Delicacy


class OpenBooth(Booth):

    def __init__(self, booth_number: int,  capacity: int):
        super().__init__(booth_number, capacity)

    def reserve(self, number_of_people: int):
        Delicacy.price = number_of_people * 2.5
        self.is_reserved = True


top = OpenBooth(10, 100)
print(top.reserve(2))
print(Delicacy.price)
print(top.is_reserved)
