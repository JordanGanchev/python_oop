from project.booths.booth import Booth
from project.delicacies.delicacy import Delicacy


class PrivateBooth(Booth):

    def __init__(self, booth_number: int,  capacity: int):
        super().__init__(booth_number, capacity)

    def reserve(self, number_of_people: int):
        Delicacy.price = number_of_people * 3.5
        self.is_reserved = True
